<template>
  <div class="p-4 text-gray-700">
    <h2 class="text-lg font-semibold mb-3">Editor</h2>
    <p>This is the editor section. Content will be added later.</p>
  </div>
</template>

<script setup lang="ts">
// Empty for now — no props, no logic
</script>
