import { createRouter, createWebHistory } from 'vue-router'
import type { RouteRecordRaw } from 'vue-router'

import Signup from '../views/SignupView.vue'
import Login from '../views/LoginView.vue'
import Dashboard from '../views/DashboardView.vue'
import ProjectDetail from '../views/ProjectDetailView.vue'
import Settings from '@/views/SettingsView.vue'
import Channels from '@/views/ChannelsView.vue'
import DashboardEditor from '@/views/DashboardEditor.vue'

const routes: Array<RouteRecordRaw> = [
  { path: '/', redirect: '/login' },
  { path: '/signup', component: Signup },
  { path: '/login', component: Login },
  {
    path: '/dashboard',
    component: Dashboard,
    meta: { requiresAuth: true },
  },
  { path: '/projects/:id', component: ProjectDetail, props: true },
  { path: '/settings', component: Settings },
  { path: '/channels', component: Channels },
  { path: '/dashboard/editor/:id', component: DashboardEditor, meta: { requiresAuth: true } },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token')

  // 1. Protected routes → require token
  if (to.meta.requiresAuth && !token) {
    return next('/login')
  }

  // 2. If logged in → block login/signup pages
  if ((to.path === '/login' || to.path === '/signup') && token) {
    return next('/dashboard')
  }

  next()
})

export default router
