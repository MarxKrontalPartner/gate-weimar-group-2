<template>
  <div class="flex h-screen bg-gray-50">
    <!-- MAIN AREA -->
    <div class="flex-1 flex flex-col">
      <!-- PAGE CONTENT -->
      <v-main>
        <div class="p-8">
          <h1 class="text-2xl font-semibold mb-4">Channels</h1>
          <p>This is the channels page. Channels content will go here</p>
        </div>
      </v-main>
    </div>
  </div>
</template>

<script setup lang="ts"></script>

<style></style>
